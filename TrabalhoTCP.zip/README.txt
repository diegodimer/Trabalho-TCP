O trabalho foi desenvolvido no Windows.
Todas as bibliotecas externas est�o na pasta do projeto com seu formato JAR.
O executavel pronto � para caso exista algum problema de compila��o no linux
